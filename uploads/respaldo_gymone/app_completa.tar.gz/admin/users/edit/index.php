<?php
session_start();

if (!isset($_SESSION['adminuser'])) {
  header("Location: ../");
  exit();
}

$userid = $_SESSION['adminuser'];

function read_env_file($file_path)
{
  $env_file = file_get_contents($file_path);
  $env_lines = explode("\n", $env_file);
  $env_data = [];

  foreach ($env_lines as $line) {
    $line_parts = explode('=', $line);
    if (count($line_parts) == 2) {
      $key = trim($line_parts[0]);
      $value = trim($line_parts[1]);
      $env_data[$key] = $value;
    }
  }

  return $env_data;
}

$env_data = read_env_file('../../../.env');

$db_host = $env_data['DB_SERVER'] ?? '';
$db_username = $env_data['DB_USERNAME'] ?? '';
$db_password = $env_data['DB_PASSWORD'] ?? '';
$db_name = $env_data['DB_NAME'] ?? '';
$currency = $env_data['CURRENCY'] ?? '';

$business_name = $env_data['BUSINESS_NAME'] ?? '';
$lang_code = $env_data['LANG_CODE'] ?? '';
$version = $env_data["APP_VERSION"] ?? '';

$lang = $lang_code;

$langDir = __DIR__ . "/../../../assets/lang/";

$langFile = $langDir . "$lang.json";

if (!file_exists($langFile)) {
  die("A nyelvi fájl nem található: $langFile");
}

$translations = json_decode(file_get_contents($langFile), true);

$conn = new mysqli($db_host, $db_username, $db_password, $db_name);

if ($conn->connect_error) {
  die("Kapcsolódási hiba: " . $conn->connect_error);
}

$sql = "SELECT is_boss FROM workers WHERE userid = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userid);
$stmt->execute();
$stmt->store_result();

$is_boss = null;

if ($stmt->num_rows > 0) {
  $stmt->bind_result($is_boss);
  $stmt->fetch();
}
$stmt->close();

// API!
$file_path = 'https://api.gymoneglobal.com/latest/version.txt';

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $file_path);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$latest_version = curl_exec($ch);
curl_close($ch);

$current_version = $version;

$alerts_html = "";

$is_new_version_available = version_compare($latest_version, $current_version) > 0;

if (isset($_GET['user']) && is_numeric($_GET['user'])) {
  $useridgymuser = $_GET['user'];

  $sql = "SELECT * FROM users WHERE userid = $useridgymuser";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $firstname = $row['firstname'];
    $lastname = $row['lastname'];
    $email = $row['email'];
    $cedula = $row['cedula'] ?? '';
    $celular = $row['celular'] ?? '';
    $regdate = $row['registration_date'];
    $lastlogin = $row['lastlogin'];
    $verify = $row['confirmed'];
    $lastip = $row['lastip'];
    $balance = $row['profile_balance'];
  } else {
    echo "The user does not exist!";
    exit;
  }
} else {
  echo "Incorrect request received!";
  exit;
}


if (isset($_POST['save'])) {
  $fields = ['firstname', 'lastname', 'email', 'cedula', 'celular'];
  $new_data = [];
  foreach ($fields as $field) {
    if (empty($_POST[$field])) {
      $alerts_html .= '<div class="alert alert-danger">Minden mező kitöltése kötelező.</div>';
      return;
    }
    $new_data[$field] = $_POST[$field];
  }

  $sql_old = "SELECT firstname, lastname, email, cedula, celular FROM users WHERE userid = ?";
  $stmt_old = $conn->prepare($sql_old);
  $stmt_old->bind_param("i", $useridgymuser);
  $stmt_old->execute();
  $result_old = $stmt_old->get_result()->fetch_assoc();
  $stmt_old->close();

  $changes = [];
  foreach ($fields as $field) {
    if ($result_old[$field] !== $new_data[$field]) {
      $changes["{$field}_old"] = $result_old[$field];
      $changes["{$field}_new"] = $new_data[$field];
    }
  }

  if (!empty($changes)) {
    $sql_update = "UPDATE users SET firstname = ?, lastname = ?, email = ?, cedula = ?, celular = ? WHERE userid = ?";
    $stmt_update = $conn->prepare($sql_update);
    $stmt_update->bind_param("sssssi", $new_data['firstname'], $new_data['lastname'], $new_data['email'], $new_data['cedula'], $new_data['celular'], $useridgymuser);

    if ($stmt_update->execute()) {
      $stmt_update->close();

      $log_sql = "INSERT INTO logs (userid, action, actioncolor, details, time) VALUES (?, ?, ?, ?, NOW())";
      $stmt_log = $conn->prepare($log_sql);
      $action = $translations["success-edit-user"];
      $color = "info";
      $details = json_encode($changes, JSON_UNESCAPED_UNICODE);
      $stmt_log->bind_param("isss", $_SESSION['adminuser'], $action, $color, $details);
      $stmt_log->execute();
      $stmt_log->close();

      $alerts_html .= '<div class="alert alert-success">' . $translations["success-update"] . '</div>';
      header("Refresh: 1");
      exit;
    } else {
      $alerts_html .= '<div class="alert alert-danger">Unexpected error: ' . $conn->error . '</div>';
    }
  }
}


if (isset($_POST['delete_user'])) {
    $sql_get = "SELECT email FROM users WHERE userid = ?";
    $stmt_get = $conn->prepare($sql_get);
    $stmt_get->bind_param("i", $useridgymuser);
    $stmt_get->execute();
    $result_old = $stmt_get->get_result()->fetch_assoc();
    $stmt_get->close();

    if ($result_old) {
        $sql_delete = "DELETE FROM users WHERE userid = ?";
        $stmt_delete = $conn->prepare($sql_delete);
        $stmt_delete->bind_param("i", $useridgymuser);

        if ($stmt_delete->execute()) {
            $stmt_delete->close();

            $changes = [
                "userid" => $useridgymuser,
                "email" => $result_old['email'],
                "balance" => $balance,
                "deleted_at" => date("Y-m-d H:i:s")
            ];

            $log_action = $translations['success-delete-user'];
            $log_color = 'danger';
            $log_details = json_encode($changes, JSON_UNESCAPED_UNICODE);

            $log_sql = "INSERT INTO logs (userid, action, actioncolor, details, time) VALUES (?, ?, ?, ?, NOW())";
            $stmt_log = $conn->prepare($log_sql);
            $stmt_log->bind_param("isss", $_SESSION['adminuser'], $log_action, $log_color, $log_details);
            $stmt_log->execute();
            $stmt_log->close();

            header("Location: ../");
            exit;
        } else {
            $alerts_html .= '<div class="alert alert-danger" role="alert">' . $translations["deletefail"] . '</div>';
        }
    } else {
        $alerts_html .= '<div class="alert alert-warning" role="alert">A felhasználó nem található.</div>';
    }

    $conn->close();
}


$today = date('Y-m-d');

$sql = "SELECT * FROM current_tickets WHERE userid = ? AND expiredate >= ? ORDER BY expiredate DESC LIMIT 1";

if ($stmt = $conn->prepare($sql)) {
  $stmt->bind_param("is", $useridgymuser, $today);
  $stmt->execute();
  $result = $stmt->get_result();

  if ($row = $result->fetch_assoc()) {
    $ticket_name = $row['ticketname'];
    $ticket_buydate = $row['buydate'];
    $ticket_expiredate = $row['expiredate'];
    $ticket_opportunities = $row['opportunities'];

    $buyDate = new DateTime($ticket_buydate);
    $expireDate = new DateTime($ticket_expiredate);
    $todayDate = new DateTime($today);

    $ticket_total_days = $buyDate->diff($expireDate)->days;

    if ($todayDate <= $expireDate) {
      $ticket_remaining_days = $todayDate->diff($expireDate)->days;
    } else {
      $ticket_remaining_days = 0;
    }

    $ticket_remaining_percent = $ticket_total_days > 0
      ? round(($ticket_remaining_days / $ticket_total_days) * 100)
      : 0;
  } else {
    $ticket_name = null;
    $ticket_buydate = null;
    $ticket_expiredate = null;
    $ticket_opportunities = null;

    $ticket_total_days = 0;
    $ticket_remaining_days = 0;
    $ticket_remaining_percent = 0;
  }

  $translated_text = str_replace(
    ['{totalday}', '{leftday}'],
    [$ticket_total_days, $ticket_remaining_days],
    $translations['daytovalidity']
  );

  $stmt->close();
} else {
  echo "Hiba a lekérdezés előkészítésekor: " . $conn->error;
}



if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['userid'])) {

  $sql_update = "UPDATE users SET confirmed = 'Yes' WHERE userid = $useridgymuser";

  if ($conn->query($sql_update) === TRUE) {
    $alerts_html .= '<div class="alert alert-success" role="alert">' . $translations["regconfirm"] . '</div>';

    $action = $translations['regconfirm'] . ' ID: ' . $useridgymuser;
    $actioncolor = 'success';
    $sql = "INSERT INTO logs (userid, action, actioncolor, time) VALUES (?, ?, ?, NOW())";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iss", $userid, $action, $actioncolor);
    $stmt->execute();

    header("Refresh:2");
    exit;
  } else {
    $alerts_html .= '<div class="alert alert-danger" role="alert">Unexpected error: ' . $conn->error . '</div>';
  }

  $conn->close();
}

?>




<!DOCTYPE html>
<html lang="<?php echo $lang_code; ?>">

<head>
  <meta charset="UTF-8">
  <title><?php echo $translations["dashboard"]; ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="../../../assets/css/dashboard.css">
  <link rel="shortcut icon" href="https://gymoneglobal.com/assets/img/logo.png" type="image/x-icon">
</head>
<!-- ApexCharts -->
<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>

<body>
  <nav class="navbar navbar-inverse visible-xs">
    <div class="container-fluid">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="#"><img src="../../../assets/img/logo.png" width="50px" alt="Logo"></a>
      </div>
      <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav navbar-nav">
          <li><a href="../../dashboard"><i class="bi bi-speedometer"></i> <?php echo $translations["mainpage"]; ?></a>
          </li>
          <li class="active"><a href="../"><i class="bi bi-people"></i> <?php echo $translations["users"]; ?></a></li>
          <li><a href="../../statistics"><i class="bi bi-bar-chart"></i> <?php echo $translations["statspage"]; ?></a>
          </li>
          <li><a href="../../boss/sell"><i class="bi bi-shop"></i> <?php echo $translations["sellpage"]; ?></a></li>
          <li><a href="../../invoices"><i class="bi bi-receipt"></i> <?php echo $translations["invoicepage"]; ?></a>
          </li>
          <?php if ($is_boss === 1) { ?>
            <li class="dropdown">
              <a class="dropdown-toggle" data-toggle="dropdown" href="#"><i class="bi bi-gear"></i>
                <?php echo $translations["settings"]; ?> <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="../../boss/mainsettings"><?php echo $translations["businesspage"]; ?></a></li>
                <li><a href="../../boss/workers"><?php echo $translations["workers"]; ?></a></li>
                <li><a href="../../boss/packages"><?php echo $translations["packagepage"]; ?></a></li>
                <li><a href="../../boss/hours"><?php echo $translations["openhourspage"]; ?></a></li>
                <li><a href="../../boss/smtp"><?php echo $translations["mailpage"]; ?></a></li>
                <li><a href="../../boss/chroom"><?php echo $translations["chroompage"]; ?></a></li>
                <li><a href="../../boss/rule"><?php echo $translations["rulepage"]; ?></a></li>
              </ul>
            </li>
          <?php } ?>
          <li><a href="../../shop/tickets"><i class="bi bi-ticket"></i> <?php echo $translations["ticketspage"]; ?></a>
          </li>
          <li><a href="../../trainers/timetable"><i class="bi bi-calendar-event"></i>
              <?php echo $translations["timetable"]; ?></a></li>
          <li><a href="../../trainers/personal"><i class="bi bi-award"></i> <?php echo $translations["trainers"]; ?></a>
          </li>
          <?php if ($is_boss === 1) { ?>
            <li><a href="../../updater"><i class="bi bi-cloud-download"></i> <?php echo $translations["updatepage"]; ?>
                <?php if ($is_new_version_available): ?>
                  <span class="badge badge-warning"><i class="bi bi-exclamation-circle"></i></span>
                <?php endif; ?>
              </a></li>
          <?php } ?>
          <li><a href="../../log"><i class="bi bi-clock-history"></i> <?php echo $translations["logpage"]; ?></a></li>
        </ul>
      </div>
    </div>
  </nav>

  <div class="container-fluid">
    <div class="row content">
      <div class="col-sm-2 sidenav hidden-xs text-center">
        <h2><img src="../../../assets/img/logo.png" width="105px" alt="Logo"></h2>
        <p class="lead mb-4 fs-4"><?php echo $business_name ?> - <?php echo $version; ?></p>
        <ul class="nav nav-pills nav-stacked">
          <li class="sidebar-item">
            <a class="sidebar-link" href="../../dashboard/">
              <i class="bi bi-speedometer"></i> <?php echo $translations["mainpage"]; ?>
            </a>
          </li>
          <li class="sidebar-item active">
            <a class="sidebar-link" href="#">
              <i class="bi bi-people"></i> <?php echo $translations["users"]; ?>
            </a>
          </li>
          <li class="sidebar-item">
            <a class="sidebar-link" href="../../statistics">
              <i class="bi bi-bar-chart"></i> <?php echo $translations["statspage"]; ?>
            </a>
          </li>
          <li class="sidebar-item">
            <a class="sidebar-link" href="../../boss/sell">
              <i class="bi bi-shop"></i> <?php echo $translations["sellpage"]; ?>
            </a>
          </li>
          <li class="sidebar-item">
            <a href="../../invoices/" class="sidebar-link">
              <i class="bi bi-receipt"></i> <?php echo $translations["invoicepage"]; ?>
            </a>
          </li>
          <?php
          if ($is_boss === 1) {
            ?>
            <li class="sidebar-header">
              <?php echo $translations["settings"]; ?>
            </li>
            <li class="sidebar-item">
              <a class="sidebar-link" href="../../boss/mainsettings">
                <i class="bi bi-gear"></i>
                <span><?php echo $translations["businesspage"]; ?></span>
              </a>
            </li>
            <li class="sidebar-item">
              <a class="sidebar-link" href="../../boss/workers">
                <i class="bi bi-people"></i>
                <span><?php echo $translations["workers"]; ?></span>
              </a>
            </li>
            <li class="sidebar-item">
              <a class="sidebar-link" href="../../boss/packages">
                <i class="bi bi-box-seam"></i>
                <span><?php echo $translations["packagepage"]; ?></span>
              </a>
            </li>
            <li class="sidebar-item">
              <a class="sidebar-link" href="../../boss/hours">
                <i class="bi bi-clock"></i>
                <span><?php echo $translations["openhourspage"]; ?></span>
              </a>
            </li>
            <li class="sidebar-item">
              <a class="sidebar-link" href="../../boss/smtp">
                <i class="bi bi-envelope-at"></i>
                <span><?php echo $translations["mailpage"]; ?></span>
              </a>
            </li>
            <li class="sidebar-item">
              <a class="sidebar-link" href="../../boss/chroom">
                <i class="bi bi-duffle"></i>
                <span><?php echo $translations["chroompage"]; ?></span>
              </a>
            </li>
            <li class="sidebar-item">
              <a class="sidebar-link" href="../../boss/rule">
                <i class="bi bi-file-ruled"></i>
                <span><?php echo $translations["rulepage"]; ?></span>
              </a>
            </li>
            <?php
          }
          ?>
          <li class="sidebar-header">
            <?php echo $translations["shopcategory"]; ?>
          </li>
          <li class="sidebar-item">
            <!-- <a class="sidebar-ling" href="../shop/gateway">
                            <i class="bi bi-shield-lock"></i>
                            <span><?php echo $translations["gatewaypage"]; ?></span>
                        </a> -->
            <a class="sidebar-ling" href="../../shop/tickets">
              <i class="bi bi-ticket"></i>
              <span><?php echo $translations["ticketspage"]; ?></span>
            </a>
          </li>
          <li class="sidebar-header">
            <?php echo $translations["trainersclass"]; ?>
          </li>
          <li><a class="sidebar-link" href="../../trainers/timetable">
              <i class="bi bi-calendar-event"></i>
              <span><?php echo $translations["timetable"]; ?></span>
            </a></li>
          <li><a class="sidebar-link" href="../../trainers/personal">
              <i class="bi bi-award"></i>
              <span><?php echo $translations["trainers"]; ?></span>
            </a></li>
          <li class="sidebar-header"><?php echo $translations["other-header"]; ?></li>
          <?php
          if ($is_boss === 1) {
            ?>
            <li class="sidebar-item">
              <a class="sidebar-ling" href="../../updater">
                <i class="bi bi-cloud-download"></i>
                <span><?php echo $translations["updatepage"]; ?></span>
                <?php if ($is_new_version_available): ?>
                  <span class="sidebar-badge badge">
                    <i class="bi bi-exclamation-circle"></i>
                  </span>
                <?php endif; ?>
              </a>
            </li>
            <?php
          }
          ?>
          <li class="sidebar-item">
            <a class="sidebar-ling" href="../../log">
              <i class="bi bi-clock-history"></i>
              <span><?php echo $translations["logpage"]; ?></span>
            </a>
          </li>
        </ul><br>
      </div>
      <br>
      <div class="col-sm-10">
        <div class="d-none topnav d-sm-inline-block">
          <a href="https://gymoneglobal.com/discord" class="btn btn-primary mx-1" target="_blank"
            rel="noopener noreferrer">
            <i class="bi bi-question-circle"></i>
            <?php echo $translations["support"]; ?>
          </a>

          <a href="https://gymoneglobal.com/docs" class="btn btn-danger" target="_blank" rel="noopener noreferrer">
            <i class="bi bi-journals"></i>
            <?php echo $translations["docs"]; ?>
          </a>
          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#logoutModal">
            <?php echo $translations["logout"]; ?>
          </button>
          <h5 id="clock" style="display: inline-block; margin-bottom: 0;"></h5>
        </div>
        <div class="row">
          <div class="col-sm-12">
            <?php echo $alerts_html; ?>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-6">
            <div class="card shadow">
              <div class="card-heading">
                <h5 class="card-title"><?php echo $translations["editprofile"]; ?></h5>
              </div>
              <form method="POST">
                <div class="row">
                  <div class="col-12 col-lg-9 order-2 order-lg-1">
                    <div class="mb-3">
                      <div class="form-group">
                        <label for="firstname"><?php echo $translations["firstname"]; ?></label>
                        <input type="text" class="form-control" id="firstname" name="firstname"
                          value="<?php echo htmlspecialchars($firstname, ENT_QUOTES, 'UTF-8'); ?>" required>
                      </div>
                    </div>
                    <div class="mb-3">
                      <div class="form-group">
                        <label for="lastname"><?php echo $translations["lastname"]; ?></label>
                        <input type="text" class="form-control" id="lastname" name="lastname"
                          value="<?php echo htmlspecialchars($lastname, ENT_QUOTES, 'UTF-8'); ?>" required>
                      </div>
                    </div>
                  </div>

                  <div class="col-12 col-lg-3 text-center order-1 order-lg-2 mb-3 mb-lg-0">
                    <?php
                    $profilePicPath = '../../../assets/img/profiles/' . $useridgymuser . '.png';
                    if (file_exists($profilePicPath)): ?>
                      <img src="<?php echo $profilePicPath; ?>" alt="User" class="img-rounded img-fluid"
                        style="max-height: 150px; width: auto;">
                    <?php endif; ?>
                  </div>
                </div>
                <div class="mb-3">
                  <div class="form-group">
                    <label for="email"><?php echo $translations["email"]; ?></label>
                    <input type="text" class="form-control" id="cedula" name="cedula" value="<?php echo htmlspecialchars($cedula, ENT_QUOTES, 'UTF-8'); ?>" placeholder="Cédula">
                    <br>
                    <input type="tel" class="form-control" id="celular" name="celular" value="<?php echo htmlspecialchars($celular, ENT_QUOTES, 'UTF-8'); ?>" placeholder="Celular">
                    <br>
                    <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($email, ENT_QUOTES, 'UTF-8'); ?>"
                      required>
                  </div>

                </div>
                <button type="submit" name="save" class="btn btn-primary"><i class="bi bi-save"></i>
                  <?php echo $translations["save"]; ?></button>
                <?php
                if ($is_boss == 1) {
                  ?>
                  <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#deleteModal"
                    data-userid="1">
                    <i class="bi bi-trash"></i>
                    <?php echo $translations["deleteuserbtn"]; ?>
                  </button> <?php
                }
                ?>

              </form>
            </div>
          </div>
          <div class="col-md-6">
            <div class="card card-default">
              <div class="card-heading">
                <h5 class="card-title"><?php echo $translations["userinfo"]; ?></h5>
              </div>
              <div class="card-body">
                <div class="form-group">
                  <label for="registerInput"><?php echo $translations["reg-date"]; ?></label>
                  <input type="text" class="form-control" id="registerInput" value="<?php echo $regdate; ?>" disabled>
                </div>
                <div class="form-group">
                  <label for="lastLoginInput"><?php echo $translations["last-login"]; ?></label>
                  <input type="text" class="form-control" id="lastLoginInput" value="<?php echo $lastlogin; ?>"
                    disabled>
                </div>
                <div class="form-group">
                  <label for="Profile_balance"><?php echo $translations["profilebalance"]; ?></label>
                  <input type="text" class="form-control" id="Profile_balance"
                    value="<?php echo $balance; ?> <?php echo $currency; ?>" disabled>
                </div>
                <div class="form-group">
                  <label for="emailVerifiedInput"><?php echo $translations["regconfirm"]; ?></label>
                  <form method="post">
                    <div class="input-group">
                      <input type="text" class="form-control text-danger" id="emailVerifiedInput"
                        value="<?php echo ($verify == "Yes") ? $translations["yes"] : $translations["no"]; ?>" disabled>
                      <span class="input-group-btn">
                        <button class="btn btn-success" type="submit" <?php if ($verify == "Yes") {
                          echo "disabled";
                        } ?>>
                          <?php echo $translations["forceregconf"]; ?>
                        </button>
                        <input type="hidden" name="userid" value="<?php echo $useridgymuser; ?>">
                      </span>
                    </div>
                  </form>
                </div>
                <div class="form-group">
                  <label for="addressInput"><?php echo $translations["lastip"]; ?></label>
                  <input type="text" class="form-control" id="addressInput" value="<?php echo htmlspecialchars($lastip, ENT_QUOTES, 'UTF-8'); ?>" disabled>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6">
            <div class="panel panel-default">
              <div class="panel-heading text-center"
                style="background: rgb(9, 80, 220);
    background: -moz-linear-gradient(90deg, rgba(9, 80, 220, 1) 0%, rgba(9, 88, 210, 1) 50%, rgba(9, 110, 210, 1) 100%);
    background: -webkit-linear-gradient(90deg, rgba(9, 80, 220, 1) 0%, rgba(9, 88, 210, 1) 50%, rgba(9, 110, 210, 1) 100%);
    background: linear-gradient(90deg, rgba(9, 80, 220, 1) 0%, rgba(9, 88, 210, 1) 50%, rgba(9, 110, 210, 1) 100%);
    filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=' #0950dc', endColorstr='#096ed2' , GradientType=1); color: white;">
                <div style="margin-bottom: 10px;">
                  <span class="label <?php
                  if (!isset($row) || $row === null) {
                    echo 'label-danger';
                  } else {
                    $expire = new DateTime($row['expiredate']);
                    $today = new DateTime(date('Y-m-d'));
                    $interval = $today->diff($expire)->format('%r%a');

                    if ($interval < 0) {
                      echo 'label-danger';
                    } elseif ($interval == 0) {
                      echo 'label-warning';
                    } else {
                      echo 'label-success';
                    }
                  }
                  ?>" style="font-size: 14px; padding: 8px 15px;">
                    <?php
                    if (!isset($row) || $row === null) {
                      echo '✗ ' . $translations["expired"];
                    } else {
                      $expire = new DateTime($row['expiredate']);
                      $today = new DateTime(date('Y-m-d'));
                      $interval = $today->diff($expire)->format('%r%a');

                      if ($interval < 0) {
                        echo '✗ ' . $translations["expired"];
                      } elseif ($interval == 0) {
                        echo $translations["expiresoon"];
                      } else {
                        echo '✓ ' . $translations["valid"];
                      }
                    }
                    ?>
                  </span>
                </div>
                <h4 style="margin: 0;"><?php echo $translations["status"]; ?></h4>
              </div>

              <div class="panel-body">
                <div class="row">
                  <div class="col-xs-12" style="margin-bottom: 15px;">
                    <div class="panel panel-default">
                      <div class="panel-body">
                        <div class="media">
                          <div class="media-left">
                            <div class="btn btn-success btn-circle"
                              style="width: 40px; height: 40px; border-radius: 50%; padding: 8px;">
                              📅
                            </div>
                          </div>
                          <div class="media-body">
                            <small class="text-muted"
                              style="text-transform: uppercase; font-weight: bold;"><?php echo $translations["buytime"]; ?></small>
                            <div style="font-weight: bold; font-size: 16px;"><?php echo $ticket_buydate; ?></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="col-xs-12" style="margin-bottom: 15px;">
                    <div class="panel panel-default">
                      <div class="panel-body">
                        <div class="media">
                          <div class="media-left">
                            <div class="btn btn-danger btn-circle"
                              style="width: 40px; height: 40px; border-radius: 50%; padding: 8px;">
                              🎯
                            </div>
                          </div>
                          <div class="media-body">
                            <small class="text-muted"
                              style="text-transform: uppercase; font-weight: bold;"><?php echo $translations["ticketspassname"]; ?></small>
                            <div style="font-weight: bold; font-size: 16px;"><?php echo $ticket_name; ?></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="col-xs-12" style="margin-bottom: 15px;">
                    <div class="panel panel-default">
                      <div class="panel-body">
                        <div class="media" style="margin-bottom: 15px;">
                          <div class="media-left">
                            <div class="btn btn-warning btn-circle"
                              style="width: 40px; height: 40px; border-radius: 50%; padding: 8px;">
                              ⏰
                            </div>
                          </div>
                          <div class="media-body">
                            <small class="text-muted"
                              style="text-transform: uppercase; font-weight: bold;"><?php echo $translations["validity"]; ?></small>
                            <div style="font-weight: bold; font-size: 16px;"><?php echo $translated_text; ?></div>
                          </div>
                        </div>
                        <div class="progress" style="margin-bottom: 10px;">
                          <div class="progress-bar <?php
                          echo ($ticket_remaining_percent < 20)
                            ? 'progress-bar-danger'
                            : (($ticket_remaining_percent < 40)
                              ? 'progress-bar-warning'
                              : 'progress-bar-info');
                          ?>" role="progressbar"
                            style="width: <?php echo $ticket_remaining_percent; ?>%">
                            <?php echo $ticket_remaining_percent; ?>%
                          </div>

                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="col-xs-12" style="margin-bottom: 15px;">
                    <div class="panel panel-default">
                      <div class="panel-body">
                        <div class="media" style="margin-bottom: 15px;">
                          <div class="media-left">
                            <div class="btn btn-info btn-circle"
                              style="width: 40px; height: 40px; border-radius: 50%; padding: 8px;">
                              💪
                            </div>
                          </div>
                          <div class="media-body">
                            <small class="text-muted"
                              style="text-transform: uppercase; font-weight: bold;"><?php echo $translations["tickettableoccassion"]; ?></small>
                            <div style="font-weight: bold; font-size: 16px;"><?php
                            echo is_null($ticket_opportunities) ? $translations["unlimited"] : $ticket_opportunities . ' ' . $translations["occassion_left"];
                            ?>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- EXIT MODAL -->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" style="margin-top: 100px;">
      <div class="modal-content" style="border: none; box-shadow: 0 0 40px rgba(0,0,0,.2);">
        <div class="modal-body text-center" style="padding: 40px;">

          <div style="margin-bottom: 25px;">
            <div style="width: 80px; height: 80px; margin: 0 auto;
                                background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
                                border-radius: 50%;
                                display: flex; align-items: center; justify-content: center;">
              <i class="bi bi-box-arrow-right" style="color: #fff; font-size: 40px;"></i>
            </div>
          </div>

          <h4 style="font-weight: bold; margin-bottom: 15px;">
            <p><?php echo $translations["exit-modal"]; ?></p>
          </h4>

          <div class="text-center">
            <a type="button" class="btn btn-default" data-dismiss="modal"
              style="padding: 8px 25px; margin-right: 10px;">
              <i class="bi bi-x-circle" style="margin-right: 5px;"></i>
              <?php echo $translations["not-yet"]; ?>
            </a>

            <a href="../../logout.php" type="button" class="btn btn-danger" style="padding: 8px 25px;">
              <i class="bi bi-check-circle" style="margin-right: 5px;"></i>
              <?php echo $translations["confirm"]; ?>
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- DELETE USER MODAL -->

  <!-- Modal -->
  <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="deleteModalLabel"><?php echo $translations["deleteuserbtn"]; ?></h5>
        </div>
        <div class="modal-body">
          <p><?php echo $translations["undoallert"]; ?></p>
          <code><?php echo $firstname; ?> <?php echo $lastname; ?> <?php echo $translations["identifier"]; ?> <?php echo $useridgymuser; ?></code>
        </div>
        <div class="modal-footer">
          <form method="post" action="">
            <input type="hidden" name="userid" id="userid" value="<?php echo $useridgymuser; ?>">
            <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="bi bi-x-lg"></i>
              <?php echo $translations["not-yet"]; ?></button>
            <button type="submit" name="delete_user" class="btn btn-danger"><i class="bi bi-exclamation-triangle"></i>
              <?php echo $translations["delete"]; ?></button>
          </form>
        </div>
      </div>
    </div>
  </div>

  <!-- SCRIPTS! -->
  <script src="../../../assets/js/date-time.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</body>

</html>